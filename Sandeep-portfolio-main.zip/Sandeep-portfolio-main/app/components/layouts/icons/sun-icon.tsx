'use client';

import classNames from 'classnames';
import type { Variants } from 'motion/react';
import { motion, useAnimation } from 'motion/react';
import type { HTMLAttributes } from 'react';
import { forwardRef, useImperativeHandle, useRef } from 'react';

interface SunMediumIconHandle {
	startAnimation: () => void;
	stopAnimation: () => void;
}

interface SunMediumIconProps extends HTMLAttributes<HTMLDivElement> {
	size?: number;
}

const pathVariants: Variants = {
	normal: { opacity: 1 },
	animate: (i: number) => ({
		opacity: [0, 1],
		transition: { delay: i * 0.1, duration: 0.3 },
	}),
};

const SunMediumIcon = forwardRef<SunMediumIconHandle, SunMediumIconProps>(
	({ onMouseEnter, onMouseLeave, className, size = 28, ...props }, ref) => {
		const controls = useAnimation();
		const isControlledRef = useRef(false);

		useImperativeHandle(ref, () => {
			isControlledRef.current = true;

			return {
				startAnimation: () => controls.start('animate'),
				stopAnimation: () => controls.start('normal'),
			};
		});

		const handleMouseEnter = (e: React.MouseEvent<HTMLDivElement>) => {
			if (!isControlledRef.current) {
				controls.start('animate');
			} else {
				onMouseEnter?.(e);
			}
		};

		const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
			if (!isControlledRef.current) {
				controls.start('normal');
			} else {
				onMouseLeave?.(e);
			}
		};

		return (
			<div
				className={classNames(
					`cursor-pointer select-none p-2 hover:bg-accent rounded-md transition-colors duration-200 flex items-center justify-center`,
					className,
				)}
				onMouseEnter={handleMouseEnter}
				onMouseLeave={handleMouseLeave}
				{...props}
			>
				<svg
					xmlns='http://www.w3.org/2000/svg'
					width={size}
					height={size}
					viewBox='0 0 24 24'
					fill='none'
					stroke='currentColor'
					strokeWidth='2'
					strokeLinecap='round'
					strokeLinejoin='round'
				>
					<circle cx='12' cy='12' r='4' />
					{[
						'M12 3v1',
						'M12 20v1',
						'M3 12h1',
						'M20 12h1',
						'm18.364 5.636-.707.707',
						'm6.343 17.657-.707.707',
						'm5.636 5.636.707.707',
						'm17.657 17.657.707.707',
					].map((d, index) => (
						<motion.path
							key={d}
							d={d}
							animate={controls}
							variants={pathVariants}
							custom={index + 1}
						/>
					))}
				</svg>
			</div>
		);
	},
);

SunMediumIcon.displayName = 'SunMediumIcon';

export { SunMediumIcon };
